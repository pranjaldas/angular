import { Component,ElementRef, OnInit} from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms'

@Component({
  selector: 'app-register',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  title:string = "Registration Form";
  registrationFrom!: FormGroup; 
  constructor(){
    
  }

  ngOnInit() {
    this.registrationFrom = new FormGroup({
      firstname: new FormControl('',[Validators.required,Validators.minLength(10)]),
      lastname: new FormControl('',[Validators.required,Validators.minLength(5)]),
      email: new FormControl('',[Validators.email,Validators.required]),
      password: new FormControl('',[Validators.required,Validators.pattern('/^(?=.\d)(?=.[a-z])(?=.[A-Z])(?=.[^a-zA-Z0-9])(?!.*\s).{8,15}$/')]),
      confirmPassword: new FormControl('',[Validators.required,Validators.minLength(10)])
    });
  }
  onSubmit(){
    console.log(this.registrationFrom);
  }
  get controls() {
    return this.registrationFrom.controls;
  } 
  
 
  

}
