export class TaskService{
    getAllTasks(){
        
    }
}